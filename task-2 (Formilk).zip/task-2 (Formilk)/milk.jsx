// src/App.js
import React from 'react';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import CustomInput from './components/CustomInput';

const validationSchema = Yup.object({
  username: Yup.string()
    .min(3, 'Must be at least 3 characters')
    .max(15, 'Must be 15 characters or less')
    .required('Username is required'),
  email: Yup.string()
    .email('Invalid email address')
    .required('Email is required'),
  age: Yup.number()
    .min(18, 'You must be at least 18')
    .required('Age is required'),
  password: Yup.string()
    .min(6, 'Must be at least 6 characters')
    .required('Password is required'),
});

const App = () => {
  return (
    <div style={{ width: '400px', margin: '2rem auto' }}>
      <h2>Register Form</h2>
      <Formik
        initialValues={{ username: '', email: '', age: '', password: '' }}
        validationSchema={validationSchema}
        onSubmit={(values) => {
          alert(JSON.stringify(values, null, 2));
        }}
      >
        <Form>
          <CustomInput label="Username" name="username" type="text" />
          <CustomInput label="Email" name="email" type="email" />
          <CustomInput label="Age" name="age" type="number" />
          <CustomInput label="Password" name="password" type="password" />

          <button type="submit" style={{ padding: '0.5rem 1rem' }}>Submit</button>
        </Form>
      </Formik>
    </div>
  );
};

export default App;
