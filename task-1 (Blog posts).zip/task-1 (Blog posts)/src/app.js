import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useParams } from 'react-router-dom';

const posts = [
  { id: '1', title: 'First Post', content: 'This is the content of the first blog post.' },
  { id: '2', title: 'Second Post', content: 'This is the content of the second blog post.' },
  { id: '3', title: 'Third Post', content: 'This is the content of the third blog post.' },
];

function Home() {
  return (
    <div>
      <h2>Blog Posts</h2>
      <ul>
        {posts.map(post => (
          <li key={post.id}>
            <Link to={`/post/${post.id}`}>{post.title}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Post() {
  const { id } = useParams();
  const post = posts.find(p => p.id === id);

  if (!post) return <h2>Post Not Found</h2>;

  return (
    <div>
      <h2>{post.title}</h2>
      <p>{post.content}</p>
      <Link to="/">← Back to Home</Link>
    </div>
  );
}

function App() {
  return (
    <Router>
      <div>
        <h1>Simple Blog</h1>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/post/:id" element={<Post />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
