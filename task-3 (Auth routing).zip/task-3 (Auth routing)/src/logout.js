// Example logout function
const handleLogout = () => {
  localStorage.removeItem('auth');
  navigate('/login');
};
