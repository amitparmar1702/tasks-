// src/components/CustomInput.js
import React from 'react';
import { useField } from 'formik';

const CustomInput = ({ label, ...props }) => {
  const [field, meta] = useField(props);

  return (
    <div style={{ marginBottom: '1rem' }}>
      <label htmlFor={props.id || props.name} style={{ display: 'block', fontWeight: 'bold' }}>
        {label}
      </label>
      <input {...field} {...props} style={{ padding: '0.5rem', width: '100%' }} />
      {meta.touched && meta.error ? (
        <div style={{ color: 'red', marginTop: '0.25rem' }}>{meta.error}</div>
      ) : null}
    </div>
  );
};

export default CustomInput;
