// pages/Home.js
const Home = () => {
  return (
    <div>
      <h2>Home (Public)</h2>
    </div>
  );
};

export default Home;
